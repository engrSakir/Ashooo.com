<footer class="footer">
    <div class="container">
        <div class="text-center">
            <a href="http://datatechbd.com/" target="_blank"><b>Developed by DataTech BD Ltd. & </b></a>Copyright © 2020 Ashooo
        </div>
    </div>
</footer>
