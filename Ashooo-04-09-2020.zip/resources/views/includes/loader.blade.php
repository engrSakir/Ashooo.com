<div class="row no-gutters vh-100 loader-screen">
    <div class="col align-self-center text-white text-center">
        <img src="{{ asset('assets/mobile/img/logo.png') }}" alt="logo">
        <!-- <h1 class="mt-3"><span class="font-weight-light ">Fi</span>mobile</h1> -->
        <p class="text-mute text-uppercase small">{{ $setting->motto }}</p>
        <div class="laoderhorizontal">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</div>
